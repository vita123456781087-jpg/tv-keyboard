package com.example.tvkeyboard;

import java.util.ArrayList;
import java.util.List;

/** Раскладки клавиатуры: русская, английская, символы и цифровая панель. */
final class Layouts {

    // типы клавиш
    static final int CHAR = 0;
    static final int SHIFT = 1;
    static final int BACK = 2;
    static final int ENTER = 3;
    static final int LANG = 4;
    static final int SYM = 5;
    static final int SPACE = 6;
    static final int LEFT = 7;
    static final int RIGHT = 8;

    // режимы раскладки
    static final int MODE_RU = 0;
    static final int MODE_EN = 1;
    static final int MODE_SYM = 2;
    static final int MODE_NUM = 3;

    static final class Key {
        final int type;
        final String label;
        final float w;       // относительная ширина
        final boolean letter;

        Key(int type, String label, float w) {
            this.type = type;
            this.label = label;
            this.w = w;
            this.letter = type == CHAR && label.length() > 0
                    && Character.isLetter(label.charAt(0));
        }
    }

    private Layouts() { }

    private static Key[] chars(String s, float w) {
        Key[] r = new Key[s.length()];
        for (int i = 0; i < r.length; i++) {
            r[i] = new Key(CHAR, String.valueOf(s.charAt(i)), w);
        }
        return r;
    }

    private static Key[] one(int type, String label, float w) {
        return new Key[]{new Key(type, label, w)};
    }

    private static Key[] cat(Key[]... parts) {
        List<Key> all = new ArrayList<Key>();
        for (Key[] p : parts) {
            for (Key k : p) all.add(k);
        }
        return all.toArray(new Key[0]);
    }

    private static Key[] bottom(boolean sym, String comma, String enterLabel, String langLabel) {
        return cat(
                one(SYM, sym ? "ABC" : "?123", 1.5f),
                one(LANG, langLabel, 1.2f),
                one(LEFT, "", 1f),
                one(CHAR, comma, 0.9f),
                one(SPACE, "", 3.6f),
                one(CHAR, ".", 0.9f),
                one(RIGHT, "", 1f),
                one(ENTER, enterLabel, 1.9f));
    }

    /**
     * @param comma      символ слева от пробела ("," или "@" для почты, "/" для адреса)
     * @param enterLabel подпись клавиши Enter (пусто — значок)
     * @param langLabel  подпись клавиши языка ("RU" или "EN")
     * @param numExtra   дополнительная клавиша цифровой панели
     */
    static Key[][] build(int mode, String comma, String enterLabel, String langLabel,
                         String numExtra) {
        Key[] digits = chars("1234567890", 1.2f);

        switch (mode) {
            case MODE_RU:
                return new Key[][]{
                        digits,
                        chars("йцукенгшщзхъ", 1f),
                        chars("фывапролджэ", 1.09f),
                        cat(one(SHIFT, "", 1.5f), chars("ячсмитьбюё", 1f), one(BACK, "", 1.5f)),
                        bottom(false, comma, enterLabel, langLabel)
                };
            case MODE_SYM:
                return new Key[][]{
                        digits,
                        chars("@#$%&*-+()", 1.2f),
                        chars("!?:;\"'/\\_=", 1.2f),
                        cat(chars("~`|<>[]{}\u20AC", 1f), one(BACK, "", 1.5f)),
                        bottom(true, comma, enterLabel, langLabel)
                };
            case MODE_NUM:
                return new Key[][]{
                        chars("123", 1f),
                        chars("456", 1f),
                        chars("789", 1f),
                        cat(one(CHAR, numExtra, 1f), one(CHAR, "0", 1f), one(BACK, "", 1f)),
                        cat(one(LEFT, "", 1f), one(ENTER, enterLabel, 2f), one(RIGHT, "", 1f))
                };
            default: // MODE_EN
                return new Key[][]{
                        digits,
                        chars("qwertyuiop", 1.2f),
                        chars("asdfghjkl", 1.33f),
                        cat(one(SHIFT, "", 1.5f), chars("zxcvbnm", 1.2f), one(BACK, "", 1.5f)),
                        bottom(false, comma, enterLabel, langLabel)
                };
        }
    }
}
