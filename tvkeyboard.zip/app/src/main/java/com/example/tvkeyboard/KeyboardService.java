package com.example.tvkeyboard;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.text.InputType;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;

import java.util.Locale;

/**
 * Лёгкая клавиатура для Android TV. Без голосового ввода.
 * Управление: стрелки пульта двигают выбор, OK нажимает клавишу, Назад закрывает.
 */
public class KeyboardService extends InputMethodService implements KbView.Callback {

    private Prefs prefs;
    private KbView view;
    private EditorInfo info;

    private int mode = Layouts.MODE_RU;       // текущая раскладка
    private int letterMode = Layouts.MODE_RU; // последняя буквенная раскладка
    private int shift = 0;                    // 0 выкл, 1 одна буква, 2 постоянно
    private String comma = ",";
    private String enterLabel = "";
    private String numExtra = ".";
    private boolean password = false;
    private boolean autoCaps = true;
    private boolean sound = false;
    private boolean showPreview = true;

    @Override
    public View onCreateInputView() {
        prefs = new Prefs(this);
        view = new KbView(this);
        view.setCallback(this);
        if (getWindow() != null && getWindow().getWindow() != null) {
            Window w = getWindow().getWindow();
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        applyPrefs();
        return view;
    }

    // Показывать клавиатуру всегда: у многих приставок пульт числится «физической клавиатурой»
    @Override
    public boolean onEvaluateInputViewShown() { return true; }

    // Без полноэкранного режима ввода
    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo ei, boolean restarting) {
        super.onStartInputView(ei, restarting);
        info = ei;
        if (view == null) return;
        applyPrefs();
        setupField(ei);
        refreshPreview(getCurrentInputConnection());
    }

    // ---------------------------------------------------------- настройки

    private void applyPrefs() {
        if (prefs == null) prefs = new Prefs(this);
        float[] keyH = {0.062f, 0.072f, 0.085f};
        float[] width = {0.94f, 0.78f, 0.62f};
        int theme = prefs.get(Prefs.THEME);
        int accent = Prefs.ACCENTS[prefs.get(Prefs.ACCENT)];
        showPreview = prefs.get(Prefs.PREVIEW) == 0;
        autoCaps = prefs.get(Prefs.CAPS) == 0;
        sound = prefs.get(Prefs.SOUND) == 0;
        view.configure(Prefs.THEMES[theme], accent, keyH[prefs.get(Prefs.SIZE)],
                width[prefs.get(Prefs.WIDTH)], prefs.get(Prefs.ROUND), showPreview);
    }

    private int[] langModes() {
        int l = prefs.get(Prefs.LANGS);
        if (l == 1) return new int[]{Layouts.MODE_EN};
        if (l == 2) return new int[]{Layouts.MODE_RU};
        return new int[]{Layouts.MODE_RU, Layouts.MODE_EN};
    }

    private static boolean contains(int[] a, int v) {
        for (int x : a) if (x == v) return true;
        return false;
    }

    // Подстроить клавиатуру под тип поля ввода
    private void setupField(EditorInfo ei) {
        int it = ei.inputType;
        int cls = it & InputType.TYPE_MASK_CLASS;
        int var = it & InputType.TYPE_MASK_VARIATION;

        boolean numeric = cls == InputType.TYPE_CLASS_NUMBER
                || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME;
        boolean isText = cls == InputType.TYPE_CLASS_TEXT;
        password = (isText && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD))
                || (cls == InputType.TYPE_CLASS_NUMBER
                && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        boolean email = isText && (var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
        boolean uri = isText && var == InputType.TYPE_TEXT_VARIATION_URI;

        comma = email ? "@" : (uri ? "/" : ",");
        if (cls == InputType.TYPE_CLASS_PHONE) numExtra = "+";
        else if (cls == InputType.TYPE_CLASS_NUMBER
                && (it & InputType.TYPE_NUMBER_FLAG_SIGNED) != 0) numExtra = "-";
        else numExtra = ".";
        enterLabel = actionLabel(ei);

        int[] langs = langModes();
        if (numeric) {
            mode = Layouts.MODE_NUM;
        } else {
            int last = prefs.getInt(Prefs.LASTLANG, langs[0]);
            int pick = contains(langs, last) ? last : langs[0];
            // для почты, адресов и паролей удобнее английская раскладка
            if ((email || uri || password) && contains(langs, Layouts.MODE_EN)) {
                pick = Layouts.MODE_EN;
            }
            letterMode = pick;
            mode = pick;
        }
        shift = 0;
        InputConnection ic = getCurrentInputConnection();
        refreshAutoCaps(ic);
        buildLayout(false, 0);
    }

    private static String actionLabel(EditorInfo ei) {
        if ((ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "";
        switch (ei.imeOptions & EditorInfo.IME_MASK_ACTION) {
            case EditorInfo.IME_ACTION_GO: return "Перейти";
            case EditorInfo.IME_ACTION_SEARCH: return "Поиск";
            case EditorInfo.IME_ACTION_SEND: return "Отпр.";
            case EditorInfo.IME_ACTION_NEXT: return "Далее";
            case EditorInfo.IME_ACTION_DONE: return "Готово";
            default: return "";
        }
    }

    // keepBottom: после смены языка или символов выбор остаётся в нижнем ряду
    private void buildLayout(boolean keepBottom, int col) {
        String langLabel = letterMode == Layouts.MODE_RU ? "RU" : "EN";
        Layouts.Key[][] rows = Layouts.build(mode, comma, enterLabel, langLabel, numExtra);
        String space = letterMode == Layouts.MODE_RU ? "Пробел" : "Space";
        boolean num = mode == Layouts.MODE_NUM;
        int startR = keepBottom ? rows.length - 1 : 1;
        int startC = keepBottom ? col : (num ? 1 : 5);
        view.setLayout(rows, num, startR, startC, space);
        view.setShift(shift);
    }

    // ------------------------------------------------------ нажатия клавиш

    @Override
    public void onKey(Layouts.Key k) {
        switch (k.type) {
            case Layouts.SHIFT:
                shift = (shift + 1) % 3;
                view.setShift(shift);
                return;
            case Layouts.LANG:
                switchLang();
                return;
            case Layouts.SYM:
                toggleSym();
                return;
            default:
                break;
        }

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (k.type) {
            case Layouts.CHAR: {
                String s = (k.letter && shift > 0) ? k.label.toUpperCase(Locale.ROOT) : k.label;
                ic.commitText(s, 1);
                if (shift == 1) {
                    shift = 0;
                    view.setShift(0);
                }
                break;
            }
            case Layouts.SPACE:
                ic.commitText(" ", 1);
                break;
            case Layouts.BACK:
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                break;
            case Layouts.ENTER:
                doEnter(ic);
                break;
            case Layouts.LEFT:
                moveCursor(ic, -1);
                break;
            case Layouts.RIGHT:
                moveCursor(ic, 1);
                break;
            default:
                break;
        }
        if (sound) click();
        refreshAutoCaps(ic);
        refreshPreview(ic);
    }

    private void switchLang() {
        int[] ls = langModes();
        int i = 0;
        for (int n = 0; n < ls.length; n++) if (ls[n] == letterMode) i = n;
        letterMode = ls[(i + 1) % ls.length];
        mode = letterMode;
        prefs.putInt(Prefs.LASTLANG, letterMode);
        shift = 0;
        refreshAutoCaps(getCurrentInputConnection());
        buildLayout(true, 1); // фокус остаётся на клавише языка
    }

    private void toggleSym() {
        mode = (mode == Layouts.MODE_SYM) ? letterMode : Layouts.MODE_SYM;
        buildLayout(true, 0); // фокус остаётся на клавише ?123 / ABC
    }

    private void doEnter(InputConnection ic) {
        int opt = info != null ? info.imeOptions : 0;
        int action = opt & EditorInfo.IME_MASK_ACTION;
        if ((opt & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0
                && action != EditorInfo.IME_ACTION_NONE
                && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
    }

    private void moveCursor(InputConnection ic, int dir) {
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (et != null) {
            int pos = et.startOffset + et.selectionStart + dir;
            if (pos < 0) pos = 0;
            ic.setSelection(pos, pos);
        } else {
            sendDownUpKeyEvents(dir < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
        }
    }

    // Заглавная буква в начале предложения и в полях, где она нужна
    private void refreshAutoCaps(InputConnection ic) {
        if (!autoCaps || ic == null || info == null) return;
        if (mode == Layouts.MODE_SYM || mode == Layouts.MODE_NUM || shift == 2) return;
        int cm = ic.getCursorCapsMode(info.inputType);
        int ns = cm != 0 ? 1 : 0;
        if (ns != shift) {
            shift = ns;
            view.setShift(shift);
        }
    }

    // Строка с последними введёнными символами (для паролей показываются точки)
    private void refreshPreview(InputConnection ic) {
        if (!showPreview || ic == null) return;
        CharSequence b = ic.getTextBeforeCursor(40, 0);
        String s = b == null ? "" : b.toString();
        if (password) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(s.length(), 30); i++) sb.append('\u2022');
            s = sb.toString();
        }
        view.setPreview(s);
    }

    private void click() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
    }

    // -------------------------------------------------------- кнопки пульта

    // Enter от настоящей клавиатуры не перехватываем: только от пульта
    private static boolean fromRemote(KeyEvent e) {
        InputDevice d = e.getDevice();
        return d == null || d.getKeyboardType() != InputDevice.KEYBOARD_TYPE_ALPHABETIC;
    }

    private boolean isNavKey(int code, KeyEvent e) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_CENTER:
                return true;
            case KeyEvent.KEYCODE_ENTER:
                return fromRemote(e);
            default:
                return false;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (view != null && isInputViewShown() && isNavKey(keyCode, event)) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_LEFT: view.move(0, -1); break;
                case KeyEvent.KEYCODE_DPAD_RIGHT: view.move(0, 1); break;
                case KeyEvent.KEYCODE_DPAD_UP: view.move(-1, 0); break;
                case KeyEvent.KEYCODE_DPAD_DOWN: view.move(1, 0); break;
                default: view.activateSelected(event.getRepeatCount() > 0); break;
            }
            return true;
        }
        return super.onKeyDown(keyCode, event); // «Назад» закрывает клавиатуру
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (view != null && isInputViewShown() && isNavKey(keyCode, event)) return true;
        return super.onKeyUp(keyCode, event);
    }
}
