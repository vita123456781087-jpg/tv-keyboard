package com.example.tvkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Окно настроек клавиатуры: включение, проверка ввода и внешний вид. */
public class SettingsActivity extends Activity {

    private Prefs prefs;
    private float u;
    private int accent;
    private TextView status;

    private int px(float units) { return Math.round(units * u); }

    private TextView text(String s, float sizeU, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        u = getResources().getDisplayMetrics().widthPixels / 100f;
        accent = Prefs.ACCENTS[prefs.get(Prefs.ACCENT)];

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0F18);
        sv.setVerticalScrollBarEnabled(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(px(8f), px(5f), px(8f), px(6f));

        TextView title = text("Лёгкая клавиатура", 4f, Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        col.addView(title);
        col.addView(text("Без голосового ввода. Стрелки пульта двигают выбор, OK нажимает клавишу, Назад закрывает.",
                1.7f, 0x99FFFFFF));

        status = text("", 1.9f, Color.WHITE);
        status.setPadding(0, px(2f), 0, px(1f));
        col.addView(status);

        col.addView(actionRow("Включить клавиатуру в системе", () -> {
            try {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            } catch (Exception e) {
                toast("На этой приставке нет окна настроек клавиатур. Включите через ADB (команды внизу).");
            }
        }), rowLp());
        col.addView(actionRow("Выбрать клавиатуру по умолчанию", () -> {
            try {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showInputMethodPicker();
            } catch (Exception e) {
                toast("Не удалось открыть выбор клавиатуры. Выберите через ADB (команды внизу).");
            }
        }), rowLp());

        col.addView(sectionTitle("ПРОВЕРКА ВВОДА"));
        EditText et = new EditText(this);
        et.setHint("Нажмите OK здесь и введите текст");
        et.setHintTextColor(0x66FFFFFF);
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_PX, 2f * u);
        et.setSingleLine(true);
        et.setPadding(px(1.4f), px(1.2f), px(1.4f), px(1.2f));
        GradientDrawable ebg = new GradientDrawable();
        ebg.setColor(0x22FFFFFF);
        ebg.setCornerRadius(0.8f * u);
        et.setBackground(ebg);
        col.addView(et, rowLp());

        col.addView(sectionTitle("ВНЕШНИЙ ВИД И ПОВЕДЕНИЕ"));
        for (Prefs.Opt o : Prefs.OPTS) col.addView(optRow(o), rowLp());

        col.addView(sectionTitle("ВКЛЮЧЕНИЕ ЧЕРЕЗ ADB (если нет окна настроек)"));
        TextView cmds = text("ime enable com.example.tvkeyboard/.KeyboardService\n"
                + "ime set com.example.tvkeyboard/.KeyboardService", 1.5f, 0xCCFFFFFF);
        cmds.setTypeface(Typeface.MONOSPACE);
        col.addView(cmds);
        col.addView(text("В приложении ADB TV вводите команды без слова adb shell.", 1.4f, 0x77FFFFFF));

        sv.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_INPUT_METHODS);
        String def = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean en = enabled != null && enabled.contains(getPackageName());
        boolean sel = def != null && def.contains(getPackageName());
        if (sel) {
            status.setText("Состояние: клавиатура включена и выбрана");
            status.setTextColor(0xFF4ADE80);
        } else if (en) {
            status.setText("Состояние: включена, но не выбрана. Нажмите «Выбрать клавиатуру»");
            status.setTextColor(0xFFFBBF24);
        } else {
            status.setText("Состояние: не включена. Нажмите «Включить клавиатуру»");
            status.setTextColor(0xFFF87171);
        }
    }

    // ----------------------------------------------------------- строки

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = px(0.4f);
        return lp;
    }

    private TextView sectionTitle(String s) {
        TextView hd = text(s, 1.4f, accent);
        hd.setPadding(px(0.5f), px(2.2f), 0, px(0.6f));
        return hd;
    }

    private Drawable rowBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(0x33FFFFFF);
        on.setCornerRadius(0.8f * u);
        on.setStroke(Math.max(2, Math.round(0.2f * u)), accent);
        GradientDrawable off = new GradientDrawable();
        off.setColor(0x14FFFFFF);
        off.setCornerRadius(0.8f * u);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, off);
        return sl;
    }

    private android.view.View actionRow(String title, final Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.6f), px(1.4f), px(1.6f), px(1.4f));
        r.addView(text(title, 2f, Color.WHITE));
        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> action.run());
        return r;
    }

    private android.view.View optRow(final Prefs.Opt o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.6f), px(1.4f), px(1.6f), px(1.4f));

        TextView t = text(o.title, 2f, Color.WHITE);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text("", 2f, accent);
        r.addView(val);
        setValueText(val, o);

        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> change(o, val, 1));
        r.setOnKeyListener((x, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { change(o, val, 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { change(o, val, -1); return true; }
            return false;
        });
        return r;
    }

    private void setValueText(TextView val, Prefs.Opt o) {
        val.setText("‹ " + o.labels[prefs.get(o.key)] + " ›");
    }

    private void change(Prefs.Opt o, TextView val, int dir) {
        int n = o.labels.length;
        int next = (prefs.get(o.key) + dir + n) % n;
        prefs.set(o.key, next);
        setValueText(val, o);
    }
}
