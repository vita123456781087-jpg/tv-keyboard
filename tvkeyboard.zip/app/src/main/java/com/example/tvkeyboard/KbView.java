package com.example.tvkeyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * Вся клавиатура рисуется одним View: никаких сотен отдельных кнопок,
 * поэтому она очень лёгкая для слабой приставки. Выбранная клавиша
 * переключается стрелками пульта, при смене перерисовывается только её область.
 */
final class KbView extends View {

    interface Callback {
        void onKey(Layouts.Key k);
    }

    private Callback cb;
    private Layouts.Key[][] rows = new Layouts.Key[0][];
    private RectF[][] rects = new RectF[0][];
    private int selR = 0;
    private int selC = 0;
    private float anchorX = 0f;
    private int shift = 0; // 0 выкл, 1 одна буква, 2 постоянно
    private String preview = "";
    private String spaceLabel = "";
    private boolean showPreview = true;
    private boolean numericMode = false;

    private int[] th = Prefs.THEMES[0];
    private int accent = Prefs.ACCENTS[0];
    private float keyH = 60f;
    private float gap = 7f;
    private float radius = 16f;
    private float widthFrac = 0.94f;
    private int vw = 0;
    private int vh = 0;

    private final Paint panelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lineP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF tmp = new RectF();

    KbView(Context c) {
        super(c);
        textP.setTextAlign(Paint.Align.CENTER);
        iconP.setStyle(Paint.Style.STROKE);
        iconP.setStrokeCap(Paint.Cap.ROUND);
        iconP.setStrokeJoin(Paint.Join.ROUND);
        lineP.setStyle(Paint.Style.STROKE);
    }

    void setCallback(Callback c) { cb = c; }

    /** Применить внешний вид из настроек. */
    void configure(int[] theme, int accent, float keyHFrac, float widthFrac, int roundIdx,
                   boolean showPreview) {
        this.th = theme;
        this.accent = accent;
        this.showPreview = showPreview;
        this.widthFrac = widthFrac;
        float sh = getResources().getDisplayMetrics().heightPixels;
        keyH = sh * keyHFrac;
        gap = keyH * 0.12f;
        float[] r = {0.12f, 0.28f, 0.5f};
        radius = keyH * r[Math.max(0, Math.min(2, roundIdx))];
        iconP.setStrokeWidth(Math.max(2f, keyH * 0.07f));
        buildShader();
        relayout();
        requestLayout();
        invalidate();
    }

    /** Сменить раскладку и поставить выбор на клавишу (row, col). */
    void setLayout(Layouts.Key[][] rows, boolean numeric, int startR, int startC,
                   String spaceLabel) {
        this.rows = rows;
        this.numericMode = numeric;
        this.spaceLabel = spaceLabel;
        selR = Math.max(0, Math.min(startR, rows.length - 1));
        selC = Math.max(0, Math.min(startC, rows[selR].length - 1));
        relayout();
        requestLayout();
        invalidate();
    }

    void setShift(int s) {
        shift = s;
        invalidate();
    }

    void setPreview(String s) {
        preview = s == null ? "" : s;
        if (showPreview && vw > 0) {
            invalidate(0, 0, vw, Math.round(padV() + stripH() + gap));
        }
    }

    // ---------------------------------------------------------- размеры

    private float padV() { return keyH * 0.35f; }

    private float stripH() { return showPreview ? keyH * 0.75f : 0f; }

    private float totalHeight() {
        int n = rows.length;
        return padV() + stripH() + n * keyH + Math.max(0, n - 1) * gap + padV();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        if (w <= 0) w = getResources().getDisplayMetrics().widthPixels;
        setMeasuredDimension(w, resolveSize(Math.round(totalHeight()), hSpec));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        vw = w;
        vh = h;
        buildShader();
        relayout();
    }

    private void buildShader() {
        panelP.setShader(new LinearGradient(0, 0, 0, Math.max(1, vh), th[0], th[1],
                Shader.TileMode.CLAMP));
    }

    private float kbWidth() {
        float frac = numericMode ? Math.min(widthFrac, 0.42f) : widthFrac;
        return vw * frac;
    }

    private void relayout() {
        if (vw <= 0) return;
        rects = new RectF[rows.length][];
        float kbW = kbWidth();
        float left = (vw - kbW) / 2f;
        float y = padV() + stripH();
        for (int r = 0; r < rows.length; r++) {
            Layouts.Key[] row = rows[r];
            float sum = 0f;
            for (Layouts.Key k : row) sum += k.w;
            float unit = (kbW - gap * (row.length - 1)) / sum;
            rects[r] = new RectF[row.length];
            float x = left;
            for (int c = 0; c < row.length; c++) {
                float kw = unit * row[c].w;
                rects[r][c] = new RectF(x, y, x + kw, y + keyH);
                x += kw + gap;
            }
            y += keyH + gap;
        }
        if (rows.length > 0 && selR < rects.length && selC < rects[selR].length) {
            anchorX = rects[selR][selC].centerX();
        }
    }

    // ------------------------------------------------------- рисование

    @Override
    protected void onDraw(Canvas c) {
        if (vw <= 0) return;
        float pr = keyH * 0.5f;
        c.drawRoundRect(0, 0, vw, vh + pr, pr, pr, panelP);

        lineP.setColor((accent & 0x00FFFFFF) | 0x99000000);
        float lw = Math.max(2f, keyH * 0.04f);
        lineP.setStrokeWidth(lw);
        c.drawLine(pr, lw / 2f, vw - pr, lw / 2f, lineP);

        if (showPreview) drawPreview(c);
        if (rects.length != rows.length) return;

        for (int r = 0; r < rows.length; r++) {
            for (int i = 0; i < rows[r].length; i++) {
                if (r == selR && i == selC) continue;
                drawKey(c, r, i, false);
            }
        }
        if (selR < rows.length && selC < rows[selR].length) drawKey(c, selR, selC, true);
    }

    private void drawPreview(Canvas c) {
        float kbW = kbWidth();
        float left = (vw - kbW) / 2f;
        float top = padV();
        float h = stripH();
        float x = left + keyH * 0.2f;
        float avail = kbW - keyH * 0.5f;

        textP.setTextAlign(Paint.Align.LEFT);
        textP.setTextSize(keyH * 0.4f);
        textP.setColor((th[4] & 0x00FFFFFF) | 0xCC000000);
        String s = preview;
        while (s.length() > 0 && textP.measureText(s) > avail) s = s.substring(1);
        Paint.FontMetrics fm = textP.getFontMetrics();
        float base = top + h / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(s, x, base, textP);
        float tw = textP.measureText(s);

        lineP.setColor(accent);
        lineP.setStrokeWidth(Math.max(2f, keyH * 0.05f));
        float cx = x + tw + keyH * 0.06f;
        c.drawLine(cx, top + h * 0.2f, cx, top + h * 0.8f, lineP);

        lineP.setColor((th[5] & 0x00FFFFFF) | 0x33000000);
        lineP.setStrokeWidth(1.5f);
        c.drawLine(left, top + h, left + kbW, top + h, lineP);
        textP.setTextAlign(Paint.Align.CENTER);
    }

    private void drawKey(Canvas c, int r, int i, boolean sel) {
        RectF rc = rects[r][i];
        Layouts.Key k = rows[r][i];
        int fg;
        if (sel) {
            tmp.set(rc);
            tmp.inset(-gap * 0.9f, -gap * 0.9f);
            fillP.setColor((accent & 0x00FFFFFF) | 0x55000000);
            c.drawRoundRect(tmp, radius * 1.25f, radius * 1.25f, fillP);
            tmp.set(rc);
            tmp.inset(-gap * 0.35f, -gap * 0.35f);
            fillP.setColor(accent);
            c.drawRoundRect(tmp, radius, radius, fillP);
            fg = Prefs.textOn(accent);
        } else {
            int col = (k.type == Layouts.CHAR || k.type == Layouts.SPACE) ? th[2] : th[3];
            fg = th[4];
            if (k.type == Layouts.ENTER || (k.type == Layouts.SHIFT && shift > 0)) {
                col = Prefs.mix(accent, th[3], k.type == Layouts.ENTER ? 0.8f : 0.5f);
                fg = Prefs.textOn(col);
            }
            fillP.setColor(col);
            c.drawRoundRect(rc, radius, radius, fillP);
        }
        drawContent(c, rc, k, fg);
    }

    private void drawContent(Canvas c, RectF rc, Layouts.Key k, int fg) {
        float cx = rc.centerX();
        float cy = rc.centerY();
        switch (k.type) {
            case Layouts.CHAR: {
                String s = (shift > 0 && k.letter) ? k.label.toUpperCase(Locale.ROOT) : k.label;
                textP.setColor(fg);
                textP.setTextSize(keyH * 0.44f);
                drawCentered(c, s, cx, cy);
                break;
            }
            case Layouts.SPACE:
                textP.setColor((fg & 0x00FFFFFF) | 0x99000000);
                textP.setTextSize(keyH * 0.27f);
                drawCentered(c, spaceLabel, cx, cy);
                break;
            case Layouts.LANG:
            case Layouts.SYM:
                textP.setColor(fg);
                textP.setTextSize(keyH * 0.3f);
                drawCentered(c, k.label, cx, cy);
                break;
            case Layouts.ENTER:
                if (k.label.length() > 0) {
                    textP.setColor(fg);
                    textP.setTextSize(keyH * 0.28f);
                    drawCentered(c, k.label, cx, cy);
                } else {
                    iconEnter(c, cx, cy, fg);
                }
                break;
            case Layouts.SHIFT:
                iconShift(c, cx, cy, fg);
                break;
            case Layouts.BACK:
                iconBack(c, cx, cy, fg);
                break;
            case Layouts.LEFT:
                iconChevron(c, cx, cy, fg, true);
                break;
            case Layouts.RIGHT:
                iconChevron(c, cx, cy, fg, false);
                break;
            default:
                break;
        }
    }

    private void drawCentered(Canvas c, String s, float cx, float cy) {
        Paint.FontMetrics fm = textP.getFontMetrics();
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, textP);
    }

    // ---- значки (рисуются линиями, без картинок и шрифтов) ----

    private void iconBack(Canvas c, float cx, float cy, int color) {
        float s = keyH * 0.2f;
        float w = keyH * 0.5f;
        iconP.setColor(color);
        iconP.setStyle(Paint.Style.STROKE);
        path.reset();
        path.moveTo(cx - w / 2f, cy);
        path.lineTo(cx - w / 2f + s * 0.9f, cy - s);
        path.lineTo(cx + w / 2f, cy - s);
        path.lineTo(cx + w / 2f, cy + s);
        path.lineTo(cx - w / 2f + s * 0.9f, cy + s);
        path.close();
        c.drawPath(path, iconP);
        float x0 = cx + w * 0.1f;
        float d = s * 0.45f;
        c.drawLine(x0 - d, cy - d, x0 + d, cy + d, iconP);
        c.drawLine(x0 - d, cy + d, x0 + d, cy - d, iconP);
    }

    private void iconShift(Canvas c, float cx, float cy, int color) {
        float s = keyH * 0.2f;
        path.reset();
        path.moveTo(cx, cy - s);
        path.lineTo(cx + s, cy + s * 0.1f);
        path.lineTo(cx + s * 0.45f, cy + s * 0.1f);
        path.lineTo(cx + s * 0.45f, cy + s * 0.9f);
        path.lineTo(cx - s * 0.45f, cy + s * 0.9f);
        path.lineTo(cx - s * 0.45f, cy + s * 0.1f);
        path.lineTo(cx - s, cy + s * 0.1f);
        path.close();
        iconP.setColor(color);
        iconP.setStyle(shift > 0 ? Paint.Style.FILL_AND_STROKE : Paint.Style.STROKE);
        c.drawPath(path, iconP);
        if (shift == 2) {
            iconP.setStyle(Paint.Style.STROKE);
            c.drawLine(cx - s * 0.45f, cy + s * 1.35f, cx + s * 0.45f, cy + s * 1.35f, iconP);
        }
        iconP.setStyle(Paint.Style.STROKE);
    }

    private void iconEnter(Canvas c, float cx, float cy, int color) {
        float s = keyH * 0.2f;
        iconP.setColor(color);
        iconP.setStyle(Paint.Style.STROKE);
        path.reset();
        path.moveTo(cx + s, cy - s);
        path.lineTo(cx + s, cy);
        path.lineTo(cx - s, cy);
        path.moveTo(cx - s + s * 0.7f, cy - s * 0.6f);
        path.lineTo(cx - s, cy);
        path.lineTo(cx - s + s * 0.7f, cy + s * 0.6f);
        c.drawPath(path, iconP);
    }

    private void iconChevron(Canvas c, float cx, float cy, int color, boolean left) {
        float s = keyH * 0.2f;
        float d = left ? 1f : -1f;
        iconP.setColor(color);
        iconP.setStyle(Paint.Style.STROKE);
        path.reset();
        path.moveTo(cx + d * s * 0.4f, cy - s);
        path.lineTo(cx - d * s * 0.4f, cy);
        path.lineTo(cx + d * s * 0.4f, cy + s);
        c.drawPath(path, iconP);
    }

    // ------------------------------------------------------- управление

    /** Сдвинуть выбор: dr по строкам, dc по клавишам (с переходом по кругу). */
    void move(int dr, int dc) {
        if (rows.length == 0 || rects.length != rows.length) return;
        int oldR = selR;
        int oldC = selC;
        if (dc != 0) {
            int n = rows[selR].length;
            selC = (selC + dc + n) % n;
            anchorX = rects[selR][selC].centerX();
        } else {
            selR = (selR + dr + rows.length) % rows.length;
            selC = nearest(selR, anchorX);
        }
        invalidateKey(oldR, oldC);
        invalidateKey(selR, selC);
    }

    private int nearest(int r, float x) {
        int best = 0;
        float bd = Float.MAX_VALUE;
        for (int c = 0; c < rects[r].length; c++) {
            float d = Math.abs(rects[r][c].centerX() - x);
            if (d < bd) {
                bd = d;
                best = c;
            }
        }
        return best;
    }

    private void invalidateKey(int r, int c) {
        if (r >= rects.length || c >= rects[r].length) return;
        RectF rc = rects[r][c];
        float p = gap * 3f;
        invalidate((int) (rc.left - p), (int) (rc.top - p),
                (int) (rc.right + p) + 1, (int) (rc.bottom + p) + 1);
    }

    /** Нажать выбранную клавишу. При удержании OK повторяются только удаление, пробел и курсор. */
    void activateSelected(boolean repeat) {
        if (cb == null || selR >= rows.length || selC >= rows[selR].length) return;
        Layouts.Key k = rows[selR][selC];
        if (repeat && !(k.type == Layouts.BACK || k.type == Layouts.SPACE
                || k.type == Layouts.LEFT || k.type == Layouts.RIGHT)) {
            return;
        }
        cb.onKey(k);
    }

    // ------------------------------------------------- мышь и касания

    private boolean pick(float x, float y, boolean activate) {
        if (rects.length != rows.length) return false;
        for (int r = 0; r < rects.length; r++) {
            for (int i = 0; i < rects[r].length; i++) {
                tmp.set(rects[r][i]);
                tmp.inset(-gap / 2f, -gap / 2f);
                if (tmp.contains(x, y)) {
                    if (r != selR || i != selC) {
                        int oldR = selR;
                        int oldC = selC;
                        selR = r;
                        selC = i;
                        anchorX = rects[r][i].centerX();
                        invalidateKey(oldR, oldC);
                        invalidateKey(r, i);
                    }
                    if (activate) activateSelected(false);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
            pick(e.getX(), e.getY(), false);
        } else if (a == MotionEvent.ACTION_UP) {
            pick(e.getX(), e.getY(), true);
        }
        return true;
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_HOVER_MOVE) {
            pick(e.getX(), e.getY(), false); // воздушная мышь: клавиша подсвечивается под курсором
            return true;
        }
        return super.onGenericMotionEvent(e);
    }
}
