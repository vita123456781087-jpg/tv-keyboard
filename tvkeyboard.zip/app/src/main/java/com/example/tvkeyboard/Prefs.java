package com.example.tvkeyboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/** Настройки клавиатуры. Общие для службы клавиатуры и окна настроек. */
final class Prefs {

    static final String THEME = "theme", ACCENT = "accent", SIZE = "size", WIDTH = "width",
            ROUND = "round", LANGS = "langs", PREVIEW = "preview", SOUND = "sound",
            CAPS = "caps";
    static final String LASTLANG = "last_lang";

    static final class Opt {
        final String key;
        final String title;
        final int def;
        final String[] labels;

        Opt(String key, String title, int def, String... labels) {
            this.key = key;
            this.title = title;
            this.def = def;
            this.labels = labels;
        }
    }

    // верх фона, низ фона, клавиша, служебная клавиша, текст, приглушённый текст
    static final int[][] THEMES = {
            {0xF2121827, 0xF20A0E18, 0xFF222B3D, 0xFF161D2B, 0xFFFFFFFF, 0xFF9AA4B8}, // Ночь
            {0xF2181A1D, 0xF20F1113, 0xFF2A2D31, 0xFF1C1E21, 0xFFFFFFFF, 0xFFA0A4AA}, // Графит
            {0xFF000000, 0xFF000000, 0xFF1A1A1A, 0xFF0D0D0D, 0xFFFFFFFF, 0xFF888888}, // Чёрная
            {0xF2EEF1F6, 0xF2DDE3EC, 0xFFFFFFFF, 0xFFC9D1DE, 0xFF1B2230, 0xFF5F6B80}  // Светлая
    };

    // Голубой, Фиолетовый, Розовый, Оранжевый, Зелёный, Красный, Белый
    static final int[] ACCENTS = {
            0xFF38BDF8, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFF22C55E, 0xFFEF4444, 0xFFFFFFFF
    };

    static final Opt[] OPTS = {
            new Opt(THEME, "Тема", 0, "Ночь", "Графит", "Чёрная", "Светлая"),
            new Opt(ACCENT, "Акцентный цвет", 0, "Голубой", "Фиолетовый", "Розовый",
                    "Оранжевый", "Зелёный", "Красный", "Белый"),
            new Opt(SIZE, "Размер клавиш", 1, "Мелкие", "Средние", "Крупные"),
            new Opt(WIDTH, "Ширина клавиатуры", 0, "Во весь экран", "Узкая", "Компактная"),
            new Opt(ROUND, "Скругление клавиш", 1, "Острые", "Средние", "Большие"),
            new Opt(LANGS, "Языки", 0, "Русский + English", "Только English", "Только русский"),
            new Opt(PREVIEW, "Строка с введённым текстом", 0, "Показывать", "Скрыть"),
            new Opt(CAPS, "Автозаглавная буква", 0, "Вкл", "Выкл"),
            new Opt(SOUND, "Звук нажатия", 1, "Вкл", "Выкл")
    };

    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE);
    }

    int get(String key) {
        for (Opt o : OPTS) {
            if (o.key.equals(key)) {
                int v = sp.getInt(key, o.def);
                return Math.max(0, Math.min(o.labels.length - 1, v));
            }
        }
        return sp.getInt(key, 0);
    }

    void set(String key, int v) { sp.edit().putInt(key, v).apply(); }

    int getInt(String key, int def) { return sp.getInt(key, def); }

    void putInt(String key, int v) { sp.edit().putInt(key, v).apply(); }

    // ---- цветовые помощники ----
    static int mix(int color, int base, float t) {
        int r = Math.round(Color.red(color) * t + Color.red(base) * (1 - t));
        int g = Math.round(Color.green(color) * t + Color.green(base) * (1 - t));
        int b = Math.round(Color.blue(color) * t + Color.blue(base) * (1 - t));
        return Color.rgb(r, g, b);
    }

    // Чёрный или белый текст в зависимости от яркости фона
    static int textOn(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.72 ? 0xFF101010 : Color.WHITE;
    }
}
